package org.xilian.xilianai;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public final class SnapshotDiffTest {
    private static void expect(String name, List<String> actual, String... expected) {
        List<String> want = Arrays.asList(expected);
        if (!actual.equals(want)) {
            throw new AssertionError(name + " expected=" + want + " actual=" + actual);
        }
        System.out.println("PASS " + name);
    }

    private static List<String> withFooter(List<String> body, List<String> footer) {
        List<String> all = new java.util.ArrayList<>(body);
        all.addAll(footer);
        return all;
    }

    public static void main(String[] args) {
        expect("append-only", SnapshotDiff.computeFresh(
                Arrays.asList("a", "b", "c"), Arrays.asList("a", "b", "c", "d")), "d");
        expect("same-text-new-message", SnapshotDiff.computeFresh(
                Arrays.asList("a", "b"), Arrays.asList("a", "b", "b")), "b");
        expect("two-identical-new-messages", SnapshotDiff.computeFresh(
                Arrays.asList("a"), Arrays.asList("a", "x", "x")), "x", "x");
        expect("scroll-overlap", SnapshotDiff.computeFresh(
                Arrays.asList("a", "b", "c"), Arrays.asList("b", "c", "d")), "d");
        expect("unrelated-history-safe", SnapshotDiff.computeFresh(
                Arrays.asList("a", "b", "c"), Arrays.asList("x", "y", "z")));
        expect("partial-tail-updated-then-append", SnapshotDiff.computeFresh(
                Arrays.asList("a", "b", "hel"), Arrays.asList("a", "b", "hello", "new")), "new");
        expect("insertion-not-misread-as-new", SnapshotDiff.computeFresh(
                Arrays.asList("a", "b", "c"), Arrays.asList("a", "b", "x", "c")));
        expect("unchanged", SnapshotDiff.computeFresh(
                Arrays.asList("a", "b"), Arrays.asList("a", "b")));
        List<String> footer = Arrays.asList("早点睡", "比心", "群聊AI", "[哈欠] 哈欠", "[钱] 爱钱");
        expect("new-message-above-fixed-footer", SnapshotDiff.computeFresh(
                withFooter(Arrays.asList("管理员X", "我也在上课"), footer),
                withFooter(Arrays.asList("管理员X", "我也在上课", "测试777"), footer)), "测试777");
        expect("two-new-messages-above-footer", SnapshotDiff.computeFresh(
                withFooter(Arrays.asList("a", "b"), footer),
                withFooter(Arrays.asList("a", "b", "c", "d"), footer)), "c", "d");
        expect("partial-tail-updated-then-new-above-footer", SnapshotDiff.computeFresh(
                withFooter(Arrays.asList("a", "hel"), footer),
                withFooter(Arrays.asList("a", "hello", "new"), footer)), "new");
        expect("history-inserted-at-head-with-footer-safe", SnapshotDiff.computeFresh(
                withFooter(Arrays.asList("a", "b"), footer),
                withFooter(Arrays.asList("x", "a", "b"), footer)));
        expect("scroll-down-with-footer-safe", SnapshotDiff.computeFresh(
                withFooter(Arrays.asList("a", "b", "c"), footer),
                withFooter(Arrays.asList("b", "c", "d"), footer)));
        expect("unchanged-with-footer", SnapshotDiff.computeFresh(
                withFooter(Arrays.asList("a", "b"), footer),
                withFooter(Arrays.asList("a", "b"), footer)));
        if (SnapshotDiff.findOverlap(Collections.emptyList(), Arrays.asList("a")) != 0) {
            throw new AssertionError("empty overlap should be zero");
        }
        System.out.println("PASS empty-overlap");
    }
}
