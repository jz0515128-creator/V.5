package org.xilian.xilianai;

public final class SendButtonMatcherTest {
    private static void check(String name, boolean actual, boolean expected) {
        if (actual != expected) {
            throw new AssertionError(name + " expected=" + expected + " actual=" + actual);
        }
        System.out.println("PASS " + name);
    }

    public static void main(String[] args) {
        check("label-send", SendButtonMatcher.isSendLabel("发送"), true);
        check("label-send-en", SendButtonMatcher.isSendLabel("Send"), true);
        check("label-send-message", SendButtonMatcher.isSendLabel("发送消息"), true);
        check("label-send-button", SendButtonMatcher.isSendLabel("发送按钮"), true);
        check("label-send-message-en", SendButtonMatcher.isSendLabel("Send message"), true);
        check("label-trailing-space", SendButtonMatcher.isSendLabel(" 发送 "), true);
        check("label-failed-not-send", SendButtonMatcher.isSendLabel("发送失败"), false);
        check("label-long-message-not-send", SendButtonMatcher.isSendLabel("发送给我一份文件吧谢谢你啦"), false);
        check("label-voice", SendButtonMatcher.isSendLabel("语音"), false);
        check("label-more-panel", SendButtonMatcher.isSendLabel("更多面板"), false);
        check("label-null", SendButtonMatcher.isSendLabel(null), false);
        check("id-send-btn", SendButtonMatcher.isSendId("com.ss.android.ugc.aweme:id/send_btn"), true);
        check("id-btn-send", SendButtonMatcher.isSendId("com.ss.android.ugc.aweme:id/btn_send"), true);
        check("id-send-only", SendButtonMatcher.isSendId("x:id/send"), true);
        check("id-sender-not-send", SendButtonMatcher.isSendId("x:id/sender_name"), false);
        check("id-empty", SendButtonMatcher.isSendId(""), false);
        check("non-send-control", SendButtonMatcher.isNonSendControl("表情"), true);
        check("non-send-control-other", SendButtonMatcher.isNonSendControl("发送"), false);
    }
}
