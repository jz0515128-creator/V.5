import unittest

from kivy.clock import Clock
from kivy.core.window import Window
from kivy.uix.textinput import TextInput

from main import ChatScreen, Window, field


class FakeApp:
    cfg = {}


class FakeChat:
    send = ChatScreen.send

    def __init__(self, text):
        self.msg = field()
        Window.add_widget(self.msg)
        Clock.tick()
        self.msg.text = text
        self.sender = TextInput(text="群友", multiline=False, input_type="text")
        self.app = FakeApp()
        self._request_pending = False
        self.messages = []

    def say(self, text, color=None):
        self.messages.append(text)


class ChatImeInputTests(unittest.TestCase):
    def make_input(self):
        text_input = field()
        Window.add_widget(text_input)
        Clock.tick()
        self.addCleanup(Window.remove_widget, text_input)
        return text_input

    def test_uses_plain_text_input_with_suggestions(self):
        text_input = self.make_input()
        self.assertEqual(text_input.input_type, "text")
        self.assertTrue(text_input.keyboard_suggestions)
        self.assertFalse(text_input.password)
        self.assertIsNone(text_input.input_filter)
        self.assertEqual(Window.softinput_mode, "resize")

    def test_english_digits_and_chinese_punctuation(self):
        text_input = self.make_input()
        text_input.insert_text("Hello 123，。！？")
        self.assertEqual(text_input.text, "Hello 123，。！？")

    def test_pinyin_preedit_can_be_replaced_by_chinese_candidate(self):
        text_input = self.make_input()
        text_input.insert_text("nihao")
        text_input.select_text(0, len(text_input.text))
        text_input.delete_selection()
        text_input.insert_text("你好，昔涟")
        self.assertEqual(text_input.text, "你好，昔涟")

    def test_cursor_movement_and_deletion(self):
        text_input = self.make_input()
        text_input.text = "A1你好，"
        text_input.cursor = (2, 0)
        text_input.insert_text("Z")
        self.assertEqual(text_input.text, "A1Z你好，")
        text_input.do_backspace()
        self.assertEqual(text_input.text, "A1你好，")
        text_input.cursor = (2, 0)
        text_input.do_backspace()
        self.assertEqual(text_input.text, "A你好，")

    def test_chat_send_keeps_message_until_request_succeeds(self):
        chat = FakeChat("你好，昔涟")
        self.addCleanup(Window.remove_widget, chat.msg)
        chat.send()
        self.assertIn("群友：你好，昔涟", chat.messages)
        self.assertEqual(chat.msg.text, "你好，昔涟")

    def test_api_failure_keeps_original_message_for_retry(self):
        chat = FakeChat("你好，昔涟")
        self.addCleanup(Window.remove_widget, chat.msg)
        chat._request_pending = True
        ChatScreen._finish_request(
            chat,
            "你好，昔涟",
            False,
            ("HTTP 429", (1, 0.5, 0.5, 1)),
        )
        self.assertEqual(chat.msg.text, "你好，昔涟")
        self.assertFalse(chat._request_pending)

    def test_successful_request_clears_only_the_sent_text(self):
        chat = FakeChat("你好，昔涟")
        self.addCleanup(Window.remove_widget, chat.msg)
        chat._request_pending = True
        ChatScreen._finish_request(
            chat,
            "你好，昔涟",
            True,
            ("连接成功", (1, 1, 1, 1)),
        )
        self.assertEqual(chat.msg.text, "")

    def test_success_does_not_clear_text_edited_while_request_was_pending(self):
        chat = FakeChat("你好，昔涟")
        self.addCleanup(Window.remove_widget, chat.msg)
        chat._request_pending = True
        chat.msg.text = "保留新的输入"
        ChatScreen._finish_request(
            chat,
            "你好，昔涟",
            True,
            ("连接成功", (1, 1, 1, 1)),
        )
        self.assertEqual(chat.msg.text, "保留新的输入")


if __name__ == "__main__":
    unittest.main()
