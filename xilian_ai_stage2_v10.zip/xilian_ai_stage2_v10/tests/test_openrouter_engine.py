import json
import os
import unittest
from unittest.mock import patch

from xilian_ai.engine import AIEngine, AIEngineError


OPENROUTER_API_BASE = "https://openrouter.ai/api/v1"
DEEPSEEK_MODEL = "deepseek/deepseek-v4.1-flash"


class FakeResponse:
    def __init__(self, status_code=200, payload=None, text=""):
        self.status_code = status_code
        self.payload = payload
        self.text = text

    def json(self):
        if isinstance(self.payload, Exception):
            raise self.payload
        return self.payload


class OpenRouterEngineTests(unittest.TestCase):
    def make_engine(self):
        return AIEngine(
            OPENROUTER_API_BASE,
            "user-configured-openrouter-key",
            DEEPSEEK_MODEL,
        )

    def test_endpoint_bearer_model_and_chinese_message(self):
        payload = {
            "choices": [{
                "message": {
                    "content": json.dumps({
                        "should_reply": True,
                        "reason": "對方直接問候",
                        "reply": "你好呀，很高興見到你。",
                    }, ensure_ascii=False)
                }
            }]
        }
        with patch("xilian_ai.engine.requests.post",
                   return_value=FakeResponse(payload=payload)) as post:
            result = self.make_engine().decide("群友：你好，昔涟")

        post.assert_called_once()
        args, kwargs = post.call_args
        self.assertEqual(args[0], OPENROUTER_API_BASE + "/chat/completions")
        self.assertEqual(
            kwargs["headers"]["Authorization"],
            "Bearer user-configured-openrouter-key",
        )
        self.assertEqual(kwargs["json"]["model"], DEEPSEEK_MODEL)
        self.assertEqual(kwargs["json"]["response_format"], {"type": "json_object"})
        self.assertIn("你好，昔涟", kwargs["json"]["messages"][1]["content"])
        self.assertEqual(result["reply"], "你好呀，很高興見到你。")

    def test_force_reply_mode_overrides_duplicate_no_reply_decision_when_text_exists(self):
        payload = {
            "choices": [{
                "message": {
                    "content": json.dumps({
                        "should_reply": False,
                        "reason": "重複內容",
                        "reply": "嗯，我看到啦，你還想聊些什麼？",
                    }, ensure_ascii=False)
                }
            }]
        }
        with patch("xilian_ai.engine.requests.post",
                   return_value=FakeResponse(payload=payload)) as post:
            result = self.make_engine().decide("測試文字", context="", force_reply=True)
        self.assertTrue(result["should_reply"])
        self.assertEqual(result["reply"], "嗯，我看到啦，你還想聊些什麼？")
        prompt = post.call_args.kwargs["json"]["messages"][1]["content"]
        self.assertIn("忽略重複內容判斷", prompt)

    def test_http_errors_are_mapped_without_response_json_crash(self):
        cases = (
            (401, "API Key 無效"),
            (429, "額度不足"),
            (500, "上游模型服務暫時錯誤"),
        )
        for status, expected in cases:
            with self.subTest(status=status):
                response = FakeResponse(
                    status_code=status,
                    payload={"error": {"message": "provider error"}},
                )
                with patch("xilian_ai.engine.requests.post", return_value=response):
                    with self.assertRaises(AIEngineError) as raised:
                        self.make_engine().decide("你好，昔涟")
                self.assertEqual(raised.exception.status_code, status)
                self.assertIn(expected, str(raised.exception))
                self.assertIn("provider error", str(raised.exception))

    def test_non_json_http_error_still_reports_status(self):
        response = FakeResponse(
            status_code=429,
            payload=ValueError("invalid JSON"),
            text="rate limited",
        )
        with patch("xilian_ai.engine.requests.post", return_value=response):
            with self.assertRaises(AIEngineError) as raised:
                self.make_engine().decide("你好，昔涟")
        self.assertEqual(raised.exception.status_code, 429)
        self.assertIn("HTTP 429", str(raised.exception))

    def test_invalid_success_json_is_reported_as_service_error(self):
        response = FakeResponse(status_code=200, payload=ValueError("bad JSON"))
        with patch("xilian_ai.engine.requests.post", return_value=response):
            with self.assertRaisesRegex(AIEngineError, "不是有效的 JSON"):
                self.make_engine().decide("你好，昔涟")

    @unittest.skipUnless(
        os.environ.get("OPENROUTER_API_KEY"),
        "Set OPENROUTER_API_KEY securely to run the live OpenRouter test.",
    )
    def test_live_chinese_connection(self):
        api_key = os.environ["OPENROUTER_API_KEY"].strip()
        result = AIEngine(
            OPENROUTER_API_BASE, api_key, DEEPSEEK_MODEL, timeout=60
        ).decide("群友：你好，昔涟")
        reply = result["reply"].strip()
        self.assertTrue(result["should_reply"])
        self.assertTrue(reply)
        self.assertTrue(any("\u4e00" <= char <= "\u9fff" for char in reply))


if __name__ == "__main__":
    unittest.main()
