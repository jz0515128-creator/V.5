"""python-for-android hook: put the accessibility <service> inside the single <application>.

Why this exists: buildozer's `android.extra_manifest_xml` is written directly under
<manifest>. Wrapping the service in its own <application> therefore produced a second
<application> element, which Android ignores, so the service never showed up in
Settings > Accessibility.

This hook runs after p4a renders AndroidManifest.xml and before Gradle assembles the
APK. It inserts android_manifest_service.xml before the one real </application>, and
fails the build if the result is not exactly one <application> that contains the service.
"""
import os
import re

SERVICE_NAME = "org.xilian.xilianai.DouyinAccessibilityService"
APPLICATION_BLOCK = re.compile(r"<application\b[^>]*?(?<!/)>.*?</application\s*>", re.S)


def merge_service(manifest_text, service_xml):
    """Return manifest_text with service_xml inside the main <application>."""
    blocks = list(APPLICATION_BLOCK.finditer(manifest_text))
    if not blocks:
        raise RuntimeError("AndroidManifest.xml has no <application> element")

    main = next((b for b in blocks if "<activity" in b.group(0)), blocks[0])
    extras = [b for b in blocks if b is not main]

    # Anything a previous step put in stray <application> wrappers is folded into main.
    folded = []
    for block in extras:
        inner = re.sub(r"^<application\b[^>]*>|</application\s*>$", "", block.group(0)).strip()
        if inner:
            folded.append(inner)

    text = manifest_text
    for block in sorted(extras, key=lambda b: b.start(), reverse=True):
        text = text[:block.start()] + text[block.end():]

    to_insert = list(folded)
    if SERVICE_NAME not in text and not any(SERVICE_NAME in part for part in folded):
        to_insert.append(service_xml.strip())

    close = text.rfind("</application>")
    if close < 0:
        raise RuntimeError("main <application> has no closing tag")
    if to_insert:
        text = text[:close] + "\n" + "\n".join(to_insert) + "\n" + text[close:]

    if len(re.findall(r"<application\b", text)) != 1:
        raise RuntimeError("manifest still has more than one <application>")
    if text.count(SERVICE_NAME) != 1:
        raise RuntimeError("accessibility service is missing or duplicated in manifest")
    return text


def _find_manifest(toolchain):
    candidates = [os.path.join(os.getcwd(), "src", "main", "AndroidManifest.xml")]
    dist = getattr(toolchain, "_dist", None)
    dist_dir = getattr(dist, "dist_dir", None)
    if dist_dir:
        candidates.append(os.path.join(dist_dir, "src", "main", "AndroidManifest.xml"))
    for path in candidates:
        if os.path.isfile(path):
            return path
    raise RuntimeError("could not find src/main/AndroidManifest.xml; tried: " + ", ".join(candidates))


def _service_xml_path():
    here = os.path.dirname(os.path.abspath(__file__))
    for base in (here, os.getcwd()):
        path = os.path.join(base, "android_manifest_service.xml")
        if os.path.isfile(path):
            return path
    raise RuntimeError("android_manifest_service.xml not found next to p4a_hook.py")


def before_apk_assemble(toolchain):
    manifest_path = _find_manifest(toolchain)
    with open(_service_xml_path(), encoding="utf-8") as handle:
        service_xml = handle.read()
    with open(manifest_path, encoding="utf-8") as handle:
        original = handle.read()
    merged = merge_service(original, service_xml)
    with open(manifest_path, "w", encoding="utf-8") as handle:
        handle.write(merged)
    print("[p4a_hook] accessibility service merged into the single <application>")
