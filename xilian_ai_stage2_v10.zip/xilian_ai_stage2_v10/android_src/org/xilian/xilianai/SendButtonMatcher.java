package org.xilian.xilianai;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;
import java.util.regex.Pattern;

/**
 * Pure helpers (no Android classes) that decide whether a node looks like the Send button.
 * Kept separate so the matching rules can be unit tested without a device.
 */
final class SendButtonMatcher {
    // Matches ids such as "send", "btn_send", "send_btn" but not "sender" / "sending".
    private static final Pattern SEND_ID = Pattern.compile("(^|[^a-z])send($|[^a-z])");
    private static final Set<String> NON_SEND = new HashSet<>(Arrays.asList(
            "语音", "表情", "更多面板", "更多", "键盘", "拍照", "相册", "图片", "加号", "+"));

    private SendButtonMatcher() {}

    static boolean isNonSendControl(String label) {
        return label != null && NON_SEND.contains(label.trim());
    }

    /** Text or content description of a node, e.g. "发送", "发送消息", "Send", "Send message". */
    static boolean isSendLabel(String label) {
        if (label == null) {
            return false;
        }
        String value = label.replace('\u00a0', ' ').trim().toLowerCase(Locale.ROOT);
        if (value.isEmpty() || value.length() > 16 || NON_SEND.contains(value)) {
            return false;
        }
        if (value.contains("失败") || value.contains("失敗") || value.contains("重发") || value.contains("重發")) {
            return false;
        }
        boolean english = value.equals("send") || value.startsWith("send ")
                || value.endsWith(" send");
        boolean chinese = value.length() <= 8
                && (value.startsWith("发送") || value.endsWith("发送")
                || value.startsWith("發送") || value.endsWith("發送"));
        return english || chinese;
    }

    /** View id resource name, e.g. "com.ss.android.ugc.aweme:id/send_btn". */
    static boolean isSendId(String viewId) {
        if (viewId == null || viewId.isEmpty()) {
            return false;
        }
        int slash = viewId.lastIndexOf('/');
        String name = (slash >= 0 ? viewId.substring(slash + 1) : viewId).toLowerCase(Locale.ROOT);
        return SEND_ID.matcher(name).find();
    }

    /** Short human-readable description used in failure diagnostics. */
    static String describe(String label, String viewId) {
        String text = label == null || label.isEmpty() ? "无文字" : label;
        if (text.length() > 12) {
            text = text.substring(0, 12);
        }
        String id = "";
        if (viewId != null && !viewId.isEmpty()) {
            int slash = viewId.lastIndexOf('/');
            id = "|" + (slash >= 0 ? viewId.substring(slash + 1) : viewId);
        }
        return text + id;
    }
}
