import hashlib
import sqlite3
from datetime import datetime
from pathlib import Path

DB_PATH = Path("xilian_memory.sqlite3")


def set_db_path(path):
    global DB_PATH
    DB_PATH = Path(path)


def init_db():
    with sqlite3.connect(DB_PATH) as conn:
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS messages (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                speaker TEXT NOT NULL,
                body TEXT NOT NULL
            )
            """
        )
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS observed_fragments (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                session_id TEXT NOT NULL,
                sender TEXT NOT NULL DEFAULT '',
                body TEXT NOT NULL,
                observed_at TEXT NOT NULL,
                observed_at_ms INTEGER NOT NULL,
                confidence REAL NOT NULL,
                read_status TEXT NOT NULL,
                fingerprint TEXT NOT NULL UNIQUE
            )
            """
        )
        conn.execute(
            "CREATE INDEX IF NOT EXISTS idx_observed_at "
            "ON observed_fragments(observed_at_ms DESC)"
        )


def add_message(speaker, body):
    with sqlite3.connect(DB_PATH) as conn:
        conn.execute(
            "INSERT INTO messages (speaker, body) VALUES (?, ?)",
            (speaker, body[:4000]),
        )


def recent_context(limit=12):
    with sqlite3.connect(DB_PATH) as conn:
        rows = conn.execute(
            "SELECT speaker, body FROM messages ORDER BY id DESC LIMIT ?",
            (limit,),
        ).fetchall()
    rows.reverse()
    return "\n".join(f"{speaker}: {body}" for speaker, body in rows)


def record_observation(observation):
    """Persist a visible-text fragment locally; return False for duplicates/empty data."""
    body = str(observation.get("text", "")).strip()[:4000]
    if not body:
        return False
    session_id = str(observation.get("session_id", "unknown"))[:200]
    sender = str(observation.get("sender", ""))[:160]
    try:
        observed_at_ms = int(observation.get("observed_at_ms", 0))
    except (TypeError, ValueError):
        observed_at_ms = 0
    if observed_at_ms <= 0:
        observed_at_ms = int(datetime.now().timestamp() * 1000)
    observed_at = datetime.fromtimestamp(observed_at_ms / 1000).astimezone().isoformat(
        timespec="seconds"
    )
    try:
        confidence = max(0.0, min(1.0, float(observation.get("confidence", 0.0))))
    except (TypeError, ValueError):
        confidence = 0.0
    read_status = str(observation.get("read_status", "partial"))[:160]
    # Android assigns a monotonically increasing sequence to each observation. Include it
    # so two genuinely separate messages with identical text within three seconds are retained,
    # while a replay of the same native queue entry still deduplicates after process restart.
    try:
        sequence = int(observation.get("seq", 0))
    except (TypeError, ValueError):
        sequence = 0
    if sequence > 0:
        identity = f"seq:{sequence}"
    else:
        # Compatibility path for historical/manual records that predate sequence IDs.
        identity = f"time:{observed_at_ms // 3000}"
    fingerprint = hashlib.sha256(
        f"{session_id}\0{sender}\0{body}\0{identity}".encode("utf-8")
    ).hexdigest()
    with sqlite3.connect(DB_PATH) as conn:
        cursor = conn.execute(
            """
            INSERT OR IGNORE INTO observed_fragments
                (session_id, sender, body, observed_at, observed_at_ms,
                 confidence, read_status, fingerprint)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (session_id, sender, body, observed_at, observed_at_ms,
             confidence, read_status, fingerprint),
        )
        return cursor.rowcount == 1


def recent_observations(limit=30):
    with sqlite3.connect(DB_PATH) as conn:
        rows = conn.execute(
            """
            SELECT session_id, sender, body, observed_at, observed_at_ms,
                   confidence, read_status
            FROM observed_fragments
            ORDER BY observed_at_ms DESC, id DESC
            LIMIT ?
            """,
            (max(1, min(int(limit), 200)),),
        ).fetchall()
    return rows


def clear_observations():
    with sqlite3.connect(DB_PATH) as conn:
        conn.execute("DELETE FROM observed_fragments")
