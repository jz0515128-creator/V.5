package org.xilian.xilianai;

import java.util.ArrayList;
import java.util.List;

/**
 * Pure snapshot-diff logic so its key cases can be tested without an Android device.
 * The input order is top-to-bottom visible text. Repeated equal strings are meaningful entries.
 */
final class SnapshotDiff {
    private static final int MAX_FRESH_PER_PASS = 12;

    private SnapshotDiff() {}

    static List<String> computeFresh(List<String> previous, List<String> current) {
        List<String> fresh = new ArrayList<>();
        if (previous == null || previous.isEmpty() || current == null || current.isEmpty()) {
            return fresh;
        }

        if (isExactPrefix(previous, current)) {
            for (int i = previous.size(); i < current.size(); i++) {
                fresh.add(current.get(i));
            }
            return limitFresh(fresh);
        }

        // Some views replace the last partially-rendered fragment while appending a new one.
        // Compare the stable prefix, then verify that the old tail did not merely shift down
        // (which would indicate an insertion/reorder rather than a bottom append).
        if (current.size() > previous.size()) {
            boolean stablePrefix = true;
            int prefixLength = Math.max(0, previous.size() - 1);
            for (int i = 0; i < prefixLength; i++) {
                if (!previous.get(i).equals(current.get(i))) {
                    stablePrefix = false;
                    break;
                }
            }
            if (stablePrefix) {
                boolean oldTailShifted = false;
                String oldTail = previous.get(previous.size() - 1);
                for (int i = previous.size() - 1; i < current.size(); i++) {
                    if (oldTail.equals(current.get(i))) {
                        oldTailShifted = true;
                        break;
                    }
                }
                if (!oldTailShifted) {
                    for (int i = previous.size(); i < current.size(); i++) {
                        fresh.add(current.get(i));
                    }
                    return limitFresh(fresh);
                }
            }
        }

        // Scrolling: the previous viewport's tail becomes the current viewport's head.
        int overlap = findOverlap(previous, current);
        if (overlap > 0) {
            for (int i = overlap; i < current.size(); i++) {
                fresh.add(current.get(i));
            }
            return limitFresh(fresh);
        }
        // No trustworthy overlap: conservatively emit nothing and let the caller reset baseline.
        return fresh;
    }

    static int findOverlap(List<String> previous, List<String> current) {
        if (previous == null || previous.isEmpty() || current == null || current.isEmpty()) {
            return 0;
        }
        for (int start = 0; start < previous.size(); start++) {
            int overlap = previous.size() - start;
            if (overlap > current.size()) {
                continue;
            }
            boolean match = true;
            for (int i = 0; i < overlap; i++) {
                if (!previous.get(start + i).equals(current.get(i))) {
                    match = false;
                    break;
                }
            }
            if (match) {
                return overlap;
            }
        }
        return 0;
    }

    static boolean isExactPrefix(List<String> previous, List<String> current) {
        if (previous == null || current == null || previous.size() > current.size()) {
            return false;
        }
        for (int i = 0; i < previous.size(); i++) {
            if (!previous.get(i).equals(current.get(i))) {
                return false;
            }
        }
        return true;
    }

    private static List<String> limitFresh(List<String> fresh) {
        if (fresh.size() > MAX_FRESH_PER_PASS) {
            return new ArrayList<>(fresh.subList(fresh.size() - MAX_FRESH_PER_PASS, fresh.size()));
        }
        return fresh;
    }
}
