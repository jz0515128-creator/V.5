import tempfile
import unittest
from pathlib import Path

from xilian_ai import store


class ObservationStoreTests(unittest.TestCase):
    def setUp(self):
        self.temp_dir = tempfile.TemporaryDirectory()
        self.previous_path = store.DB_PATH
        store.set_db_path(Path(self.temp_dir.name) / "test.sqlite3")
        store.init_db()

    def tearDown(self):
        store.set_db_path(self.previous_path)
        self.temp_dir.cleanup()

    def observation(self, **overrides):
        record = {
            "session_id": "douyin-window-7",
            "sender": "",
            "text": "你好，昔涟！🙂",
            "observed_at_ms": 1_700_000_001_000,
            "confidence": 0.45,
            "read_status": "可见文字片段（不保证消息完整）",
        }
        record.update(overrides)
        return record

    def test_chinese_fragment_and_observation_metadata_are_stored(self):
        self.assertTrue(store.record_observation(self.observation()))
        rows = store.recent_observations()
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0][0], "douyin-window-7")
        self.assertEqual(rows[0][1], "")
        self.assertEqual(rows[0][2], "你好，昔涟！🙂")
        self.assertTrue(rows[0][3])
        self.assertEqual(rows[0][4], 1_700_000_001_000)
        self.assertAlmostEqual(rows[0][5], 0.45)
        self.assertIn("不保证消息完整", rows[0][6])

    def test_near_duplicate_fragment_is_deduplicated_but_later_repeat_is_kept(self):
        first = self.observation(observed_at_ms=1_700_000_001_100)
        near_duplicate = self.observation(observed_at_ms=1_700_000_002_100)
        later_repeat = self.observation(observed_at_ms=1_700_000_010_100)
        self.assertTrue(store.record_observation(first))
        self.assertFalse(store.record_observation(near_duplicate))
        self.assertTrue(store.record_observation(later_repeat))
        self.assertEqual(len(store.recent_observations()), 2)

    def test_distinct_sequence_ids_preserve_identical_messages_within_three_seconds(self):
        first = self.observation(seq=101, observed_at_ms=1_700_000_001_100)
        second = self.observation(seq=102, observed_at_ms=1_700_000_001_900)
        replay = self.observation(seq=101, observed_at_ms=1_700_000_001_100)
        self.assertTrue(store.record_observation(first))
        self.assertTrue(store.record_observation(second))
        self.assertFalse(store.record_observation(replay))
        self.assertEqual(len(store.recent_observations()), 2)

    def test_empty_text_is_not_saved(self):
        self.assertFalse(store.record_observation(self.observation(text="  ")))
        self.assertEqual(store.recent_observations(), [])

    def test_clear_observations_does_not_clear_ai_memory(self):
        store.record_observation(self.observation())
        store.add_message("群友", "保留的对话记忆")
        store.clear_observations()
        self.assertEqual(store.recent_observations(), [])
        self.assertIn("保留的对话记忆", store.recent_context())

    def test_confidence_is_bounded(self):
        store.record_observation(self.observation(confidence=5))
        self.assertEqual(store.recent_observations()[0][5], 1.0)


if __name__ == "__main__":
    unittest.main()
